# MultiProtocol
An advanced plugin that allows different client versions to connect to your PocketMine-MP server. It supports protocols above the current protocol. Download the latest build from [Poggit CI](https://poggit.pmmp.io/ci/IceCruelStuff/MultiProtocol).
